import os, sys, time

class Functions:
    """Class for basic functions https://typergame.replit.app/docs?class=functions"""
    def __init__(self, defaultdelay: int, defaultnewline: bool):

        self.defaultdelay = defaultdelay
        self.defaultnewline = defaultnewline

    def clear(self):
        """Clears the console https://typergame.replit.app/docs?function=game.functions.clear()"""
        if os.name == "nt":
            os.system("cls")
        else:
            os.system("clear")

    def pause(self, delay: int):
        """Delays the action coming after it https://typergame.replit.app/docs?function=game.functions.pause()"""
        time.sleep(delay)

    def write(self, text: str, delay: int = None, newline: bool = None):
        """Writes the text arg out character by character https://typergame.replit.app/docs?function=game.functions.write()"""
        if delay == None:
            runningdelay = self.defaultdelay
        else:
            runningdelay = delay
        if newline == None:
            runningnewline = self.defaultnewline
        else:
            runningnewline = newline
        for char in text:
            sys.stdout.write(char)
            sys.stdout.flush()
            self.pause(runningdelay)
        if runningnewline:
            print()

    def ask(self, question: str, delay: int = None):
        """Prints out question arg with the write function and returns a user input https://typergame.replit.app/docs?function=game.functions.ask()"""
        self.write(question, delay, True)
        return input("> ")

